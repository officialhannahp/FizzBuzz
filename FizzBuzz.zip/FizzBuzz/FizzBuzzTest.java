public class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz id = new FizzBuzz();
        String result = id.fizzBuzz(2);
        System.out.println(result);
    }
}







